
const emojis = {
  chocolate:'🎂', cheese:'🍰', cupcake:'🧁',
  cookies:'🍪', strawberry:'🍓', macaron:'🍬',
  brownie:'🍫', croissant:'🥐', tiramisu:'🍮',
  truffles:'🍫', lemon:'🍋', cinnamon:'🥮',
  birthdaybox:'🎁', chocolatebox:'🎁',
  couplebox:'🎁', giftbox:'🎁', minibox:'🎁'
};

const productImages = {
  chocolate:'images/chocolate.jpg',
  cheese:'images/cheese.jpg',
  cupcake:'images/cupcake.jpg',
  cookies:'images/cookies.jpg',
  strawberry:'images/strawberry.jpg',
  macaron:'images/macaron.jpg',
  brownie:'images/brownie.jpg',
  croissant:'images/croissant.jpg',
  tiramisu:'images/tiramisu.jpg',
  truffles:'images/truffles.jpg',
  lemon:'images/lemon.jpg',
  cinnamon:'images/cinnamon.jpg'
};

let currentProducts = [];

async function loadProducts() {
  try {
    const sort = $('#sort').value;
    const category = $('#category').value;

    const data = await api(
      '/api/products?sort=' + encodeURIComponent(sort) +
      '&category=' + encodeURIComponent(category)
    );

    currentProducts = data;

    $('#product-list').innerHTML = data.length
      ? data.map(p => {
          const image = productImages[p.image];
          const emoji = emojis[p.image] || '🎁';
          const stock = Number(p.inStock) || 0;

          return `
            <article class="product">
              <div class="dessert">
                ${image
                  ? `<img src="${image}"
                      alt="${escapeHtml(p.name)}"
                      loading="lazy"
                      onerror="this.hidden=true;this.nextElementSibling.hidden=false">
                     <span class="dessert-fallback" hidden>${emoji}</span>`
                  : `<span>${emoji}</span>`
                }
              </div>

              <h3>${escapeHtml(p.name)}</h3>
              <p>${escapeHtml(p.description)}</p>
              <div class="price">${money(p.price)}</div>

              <p class="${stock > 0 ? 'stock-available' : 'stock-empty'}">
                ${stock > 0
                  ? `במלאי: ${stock} יחידות`
                  : 'אזל מהמלאי כרגע'}
              </p>

              ${stock > 0
                ? `<button class="btn" data-add="${p._id}">
                     הוסף לסל 🛒
                   </button>`
                : `<button class="btn" disabled>
                     אזל מהמלאי כרגע
                   </button>`
              }
            </article>`;
        }).join('')
      : 'לא נמצאו מוצרים בקטגוריה זו';

    document.querySelectorAll('[data-add]').forEach(button => {
      button.onclick = async () => {
        try {
          const latest = await api('/api/products');
          const product = latest.find(
            p => p._id === button.dataset.add
          );

          if (!product) return notify('המוצר לא נמצא');

          const cart = getCart();
          const existing = cart.find(
            x => x.productId === product._id
          );

          const quantity = existing
            ? Number(existing.quantity) || 0
            : 0;

          if (quantity >= product.inStock) {
            return notify('אין מספיק מלאי מהמוצר הזה');
          }

          addCart(product._id);

        } catch (e) {
          notify(e.message);
        }
      };
    });

  } catch (e) {
    notify(e.message);
  }
}

// בחירת קטגוריה מתוך הקישור של דף הבית
const params = new URLSearchParams(window.location.search);
const selectedCategory = params.get('category');

if (selectedCategory) {
  const select = $('#category');

  if ([...select.options].some(
    option => option.value === selectedCategory
  )) {
    select.value = selectedCategory;
  }
}

$('#sort').onchange = loadProducts;

$('#category').onchange = () => {
  const category = $('#category').value;
  const url = new URL(window.location.href);

  if (category === 'all') {
    url.searchParams.delete('category');
  } else {
    url.searchParams.set('category', category);
  }

  window.history.replaceState({}, '', url);
  loadProducts();
};

loadProducts();

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) loadProducts();
});

api('/api/weather')
  .then(x => {
    $('#weather').textContent =
      `🌤 מזג האוויר ב${x.city}: ${x.temperature}°C`;
  })
  .catch(() => {
    $('#weather').textContent = '🌤 מזג האוויר אינו זמין';
  });

api('/api/currency')
  .then(x => {
    $('#currency').textContent =
      `💱 דולר אחד = ₪${x.ilsPerUsd.toFixed(2)} (עדכון ${x.date})`;
  })
  .catch(() => {
    $('#currency').textContent = '💱 שער המטבע אינו זמין';
  });
