
async function loadOrders() {
  const container = document.querySelector('#orders');

  try {
    const orders = await api('/api/orders/my');

    if (!orders.length) {
      container.innerHTML = `
        <div class="orders-empty">
          <div class="orders-empty-icon">🛍️</div>
          <h3>עדיין אין לך הזמנות</h3>
          <p>זה הזמן לבחור משהו מתוק!</p>
          <a href="products.html" class="btn">
            לצפייה במוצרים
          </a>
        </div>
      `;
      return;
    }

    const statusLabels = {
      pending: 'בהכנה',
      completed: 'הושלמה',
      cancelled: 'בוטלה'
    };

    container.innerHTML = orders.map(order => {
      const status = statusLabels[order.status] || 'בטיפול';
      const statusClass =
        ['pending', 'completed', 'cancelled'].includes(order.status)
          ? order.status
          : 'pending';

      const date = new Date(order.createdAt)
        .toLocaleDateString('he-IL');

      const itemsHtml = order.items.map(item => `
        <div class="order-product-row">
          <span>
            ${escapeHtml(item.name)} × ${item.quantity}
          </span>
          <strong>
            ${money(item.price * item.quantity)}
          </strong>
        </div>
      `).join('');

      return `
        <article class="order-card">

          <div class="order-card-header">
            <div>
              <h3>
                הזמנה #${escapeHtml(order._id.slice(-6).toUpperCase())}
              </h3>
              <p>📅 ${date}</p>
            </div>

            <span class="order-status ${statusClass}">
              ${status}
            </span>
          </div>

          <div class="order-card-body">
            <h4>🧁 פריטים בהזמנה</h4>
            ${itemsHtml}
          </div>

          <div class="order-card-footer">
            <span>סה״כ לתשלום</span>
            <strong>${money(order.total)}</strong>
          </div>

        </article>
      `;
    }).join('');

  } catch (error) {
    container.innerHTML = `
      <div class="orders-empty">
        <h3>לא ניתן לטעון את ההזמנות</h3>
        <p>ודאי שאת מחוברת לחשבון ונסי לרענן.</p>
      </div>
    `;

    notify(error.message);
  }
}

loadOrders();
