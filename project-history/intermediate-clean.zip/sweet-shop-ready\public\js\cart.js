
let products = [];
let submitting = false;

const SHIPPING_FEE = 30;
const FREE_SHIPPING_MIN = 300;

function calculateTotals(subtotal) {
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_MIN
    ? 0
    : SHIPPING_FEE;

  return {
    subtotal,
    shipping,
    total: subtotal + shipping
  };
}

function updateSummary(subtotal) {
  const totals = calculateTotals(subtotal);

  $('#products-total').textContent = money(totals.subtotal);

  $('#shipping-cost').textContent =
    subtotal === 0
      ? '₪0'
      : totals.shipping === 0
        ? 'חינם 🎁'
        : money(totals.shipping);

  $('#total').textContent =
    'סה״כ: ' + money(totals.total);

  const message = $('#shipping-message');

  if (subtotal === 0) {
    message.textContent = 'הוסיפו מוצרים כדי להתחיל בהזמנה';
  } else if (subtotal >= FREE_SHIPPING_MIN) {
    message.textContent = '🎉 איזה כיף! קיבלתם משלוח חינם!';
  } else {
    const remaining = FREE_SHIPPING_MIN - subtotal;
    message.textContent =
      `🛍️ הוסיפו עוד ${money(remaining)} וקבלו משלוח חינם!`;
  }
}

// הצגת המוצרים בסל
async function render() {
  try {
    products = await api('/api/products');

    const cart = getCart().filter(item =>
      products.some(p => p._id === item.productId)
    );

    setCart(cart);

    let subtotal = 0;

    if (cart.length === 0) {
      $('#cart-list').textContent =
        'הסל ריק. אפשר לבחור קינוחים בדף המוצרים.';

      updateSummary(0);
      $('#checkout').disabled = true;
      $('#payment-section').hidden = true;
      return;
    }

    $('#checkout').disabled = false;

    $('#cart-list').innerHTML = cart.map(item => {
      const product = products.find(
        p => p._id === item.productId
      );

      const itemSubtotal = product.price * item.quantity;
      subtotal += itemSubtotal;

      return `
        <div class="cart-row">
          <div>
            <b>${escapeHtml(product.name)}</b>
            <p class="muted">${money(product.price)} ליחידה</p>
          </div>

          <label>
            כמות
            <input
              type="number"
              min="1"
              max="50"
              value="${item.quantity}"
              data-qty="${product._id}"
            >
          </label>

          <strong>${money(itemSubtotal)}</strong>

          <button
            class="btn small danger"
            data-remove="${product._id}">
            הסר
          </button>
        </div>
      `;
    }).join('');

    updateSummary(subtotal);

    document.querySelectorAll('[data-remove]').forEach(button => {
      button.onclick = () => {
        const updatedCart = getCart().filter(
          item => item.productId !== button.dataset.remove
        );

        setCart(updatedCart);
        render();
      };
    });

    document.querySelectorAll('[data-qty]').forEach(input => {
      input.onchange = () => {
        const cart = getCart();
        const item = cart.find(
          x => x.productId === input.dataset.qty
        );

        if (!item) return;

        const product = products.find(
          p => p._id === item.productId
        );

        const available = Math.max(
          0,
          Number(product?.inStock) || 0
        );

        if (available === 0) {
          notify('המוצר אזל מהמלאי כרגע');
          return;
        }

        const requested = Number(input.value) || 1;

        item.quantity = Math.max(
          1,
          Math.min(50, available, requested)
        );

        if (requested > available) {
          notify('הכמות עודכנה בהתאם למלאי הזמין');
        }

        setCart(cart);
        render();
      };
    });

  } catch (error) {
    console.error('Cart loading error:', error);
    $('#cart-list').textContent =
      'לא הצלחנו לטעון את המוצרים. נסי לרענן את הדף.';
    notify(error.message);
  }
}

// פתיחת טופס התשלום
$('#checkout').onclick = () => {
  if (!getCart().length) {
    notify('הסל ריק');
    return;
  }

  const paymentSection = $('#payment-section');

  paymentSection.hidden = false;

  paymentSection.scrollIntoView({
    behavior: 'smooth',
    block: 'start'
  });
};

// שליחת ההזמנה לשרת
$('#payment-form').onsubmit = async event => {
  event.preventDefault();

  if (submitting) return;

  const items = getCart();

  if (!items.length) {
    notify('הסל ריק');
    return;
  }

  const fullName = $('#fullName').value.trim();
  const phone = $('#phone').value.trim();

  const city = $('#city').value.trim();
  const street = $('#street').value.trim();
  const houseNumber = $('#houseNumber').value.trim();
  const apartment = $('#apartment').value.trim();
  const notes = $('#notes').value.trim();

  const address = [
    city,
    street,
    houseNumber ? `מספר ${houseNumber}` : '',
    apartment ? `דירה ${apartment}` : ''
  ].filter(Boolean).join(', ');

  $('#address').value = address;

  const paymentMethod = document.querySelector(
    'input[name="paymentMethod"]:checked'
  )?.value;

  if (
    fullName.length < 2 ||
    !/^0\d{8,9}$/.test(phone) ||
    !city ||
    !street ||
    !houseNumber ||
    address.length < 5
  ) {
    notify('יש למלא שם, טלפון וכתובת משלוח תקינים');
    return;
  }

  submitting = true;

  const submitButton = $('#payment-form button[type="submit"]');

  submitButton.disabled = true;
  submitButton.textContent = 'מבצע הזמנה...';

  try {
    await api('/api/orders', {
      method: 'POST',
      body: JSON.stringify({
        items,
        shipping: {
          fullName,
          phone,
          address,
          city,
          street,
          houseNumber,
          apartment,
          notes
        },
        paymentMethod
      })
    });

    setCart([]);
    window.location.href = 'orders.html';

  } catch (error) {
    console.error('Checkout error:', error);

    if (error.message.includes('להתחבר')) {
      notify('יש להתחבר לחשבון לפני ביצוע הזמנה');
    } else {
      notify(error.message);
    }

  } finally {
    submitting = false;
    submitButton.disabled = false;
    submitButton.textContent = 'אישור הזמנה';
  }
};

render();
