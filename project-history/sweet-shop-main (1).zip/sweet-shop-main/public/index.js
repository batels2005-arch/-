const button = document.getElementById("testButton");
const result = document.getElementById("result");

button.addEventListener("click", async () => {
    const response = await fetch("/api/test");

    const data = await response.json();

    result.textContent = data.message;
});