const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const Product = require("./models/Product");

// טעינת המשתנים מקובץ .env
dotenv.config();

const app = express();

// מאפשר לשרת לקבל JSON
app.use(express.json());

// מאפשר לשרת להציג את הקבצים שבתיקיית public
app.use(express.static("public"));

// חיבור ל-MongoDB Atlas
mongoose
    .connect(process.env.MONGO_URI)
    .then(() => {
        console.log("Connected to MongoDB Atlas!");
    })
    .catch((error) => {
        console.error("MongoDB connection error:", error);
    });

// בדיקת השרת
app.get("/api/test", (req, res) => {
    res.json({
        message: "Sweet Shop server is working!"
    });
});

// קבלת כל המוצרים
app.get("/api/products", async (req, res) => {
    try {
        const products = await Product.find();

        res.json(products);
    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "Error getting products"
        });
    }
});

// הוספת מוצר חדש
app.post("/api/products", async (req, res) => {
    try {
        const product = new Product({
            name: req.body.name,
            price: req.body.price,
            category: req.body.category,
            image: req.body.image,
            description: req.body.description,
            inStock: req.body.inStock
        });

        const savedProduct = await product.save();

        res.status(201).json(savedProduct);
    } catch (error) {
        console.error(error);

        res.status(400).json({
            message: "Error creating product"
        });
    }
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});